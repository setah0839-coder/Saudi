import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import Palestine from "@/pages/palestine";
import Kuwait from "@/pages/kuwait";
import Bosnia from "@/pages/bosnia";
import Lebanon from "@/pages/lebanon";
import Yemen from "@/pages/yemen";
import Iraq from "@/pages/iraq";
import Morocco from "@/pages/morocco";
import Pakistan from "@/pages/pakistan";
import Haiti from "@/pages/haiti";
import Nepal from "@/pages/nepal";
import TurkeySyria from "@/pages/turkeysyria";
import Sudan from "@/pages/sudan";
import LebanonPeace from "@/pages/lebanon-peace";
import EgyptPeace from "@/pages/egypt-peace";
import SyriaRefugees from "@/pages/syria-refugees";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/palestine" component={Palestine} />
      <Route path="/kuwait" component={Kuwait} />
      <Route path="/bosnia" component={Bosnia} />
      <Route path="/lebanon" component={Lebanon} />
      <Route path="/yemen" component={Yemen} />
      <Route path="/iraq" component={Iraq} />
      <Route path="/morocco" component={Morocco} />
      <Route path="/pakistan" component={Pakistan} />
      <Route path="/haiti" component={Haiti} />
      <Route path="/nepal" component={Nepal} />
      <Route path="/turkeysyria" component={TurkeySyria} />
      <Route path="/sudan" component={Sudan} />
      <Route path="/lebanon-peace" component={LebanonPeace} />
      <Route path="/egypt-peace" component={EgyptPeace} />
      <Route path="/syria-refugees" component={SyriaRefugees} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;

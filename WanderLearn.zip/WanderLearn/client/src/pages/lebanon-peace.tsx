import DetailPage from "./detail-page";
import { peaceInitiativesData } from "@shared/fazaat-data";

export default function LebanonPeace() {
  const data = peaceInitiativesData.lebanon;
  return <DetailPage {...data} />;
}

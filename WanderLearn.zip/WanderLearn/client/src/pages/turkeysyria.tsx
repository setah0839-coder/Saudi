import DetailPage from "./detail-page";
import { humanitarianAidData } from "@shared/fazaat-data";

export default function TurkeySyria() {
  const data = humanitarianAidData.turkeysyria;
  return <DetailPage {...data} />;
}

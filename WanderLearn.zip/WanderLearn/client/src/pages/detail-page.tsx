import { useRoute, Link } from "wouter";
import { motion } from "framer-motion";
import { ArrowRight, Home } from "lucide-react";
import { Button } from "@/components/ui/button";

interface DetailPageProps {
  flag: string;
  title: string;
  shortDescription: string;
  period?: string;
  year?: string;
  type?: string;
  image: string;
  fullDescription: string;
}

export default function DetailPage({
  flag,
  title,
  shortDescription,
  period,
  year,
  type,
  image,
  fullDescription,
}: DetailPageProps) {
  return (
    <div className="min-h-screen bg-background" dir="rtl">
      {/* Hero Section */}
      <div className="relative h-[500px] overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${image})` }}
        ></div>
        <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/50 to-background"></div>

        <div className="relative z-10 h-full flex flex-col justify-between max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Navigation */}
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button
                variant="outline"
                className="bg-white/10 backdrop-blur-sm border-white/20 text-white hover:bg-white/20"
                data-testid="button-back-home"
              >
                <Home className="ml-2" size={18} />
                العودة للرئيسية
              </Button>
            </Link>
          </div>

          {/* Title */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center"
          >
            <div className="text-8xl mb-4">{flag}</div>
            <h1 className="text-5xl md:text-6xl font-black text-white mb-4">{title}</h1>
            <p className="text-xl md:text-2xl text-white/90 max-w-3xl mx-auto">
              {shortDescription}
            </p>
            <div className="flex flex-wrap justify-center gap-3 mt-6">
              {period && (
                <span className="bg-primary text-primary-foreground px-6 py-2 rounded-full font-bold">
                  {period}
                </span>
              )}
              {year && (
                <span className="bg-primary text-primary-foreground px-6 py-2 rounded-full font-bold">
                  {year}
                </span>
              )}
              {type && (
                <span className="bg-accent/90 text-foreground px-6 py-2 rounded-full font-bold">
                  {type}
                </span>
              )}
            </div>
          </motion.div>
        </div>
      </div>

      {/* Content Section */}
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="prose prose-lg prose-headings:text-primary prose-h3:text-3xl prose-h3:font-bold prose-h3:mb-4 prose-h3:mt-8 prose-h4:text-2xl prose-h4:font-bold prose-h4:text-primary/90 prose-h4:mb-3 prose-h4:mt-6 prose-p:text-foreground prose-p:leading-relaxed prose-p:text-lg prose-ul:text-foreground prose-li:text-lg prose-li:leading-relaxed max-w-none"
          dangerouslySetInnerHTML={{ __html: fullDescription }}
          data-testid="content-detail"
        />

        {/* Back Button */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="mt-12 text-center"
        >
          <Link href="/">
            <Button
              size="lg"
              className="bg-primary hover:bg-primary/90 text-primary-foreground font-bold text-lg px-8"
              data-testid="button-back-bottom"
            >
              العودة للصفحة الرئيسية
              <ArrowRight className="ml-2" size={20} />
            </Button>
          </Link>
        </motion.div>
      </div>

      {/* Decorative Bottom */}
      <div className="bg-gradient-to-t from-primary/5 to-transparent py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-muted-foreground text-lg italic">
            "المملكة العربية السعودية... يد العون الممتدة للعالم"
          </p>
        </div>
      </div>
    </div>
  );
}

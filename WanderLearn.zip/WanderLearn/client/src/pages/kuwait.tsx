import DetailPage from "./detail-page";
import { historicalFazaatData } from "@shared/fazaat-data";

export default function Kuwait() {
  const data = historicalFazaatData.kuwait;
  return <DetailPage {...data} />;
}

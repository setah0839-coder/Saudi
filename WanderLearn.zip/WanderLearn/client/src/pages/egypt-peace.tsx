import DetailPage from "./detail-page";
import { peaceInitiativesData } from "@shared/fazaat-data";

export default function EgyptPeace() {
  const data = peaceInitiativesData.egypt;
  return <DetailPage {...data} />;
}

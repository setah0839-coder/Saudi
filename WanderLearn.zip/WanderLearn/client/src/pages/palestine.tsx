import DetailPage from "./detail-page";
import { historicalFazaatData } from "@shared/fazaat-data";

export default function Palestine() {
  const data = historicalFazaatData.palestine;
  return <DetailPage {...data} />;
}

import DetailPage from "./detail-page";
import { peaceInitiativesData } from "@shared/fazaat-data";

export default function SyriaRefugees() {
  const data = peaceInitiativesData.syria;
  return <DetailPage {...data} />;
}

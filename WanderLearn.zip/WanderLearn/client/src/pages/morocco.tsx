import DetailPage from "./detail-page";
import { humanitarianAidData } from "@shared/fazaat-data";

export default function Morocco() {
  const data = humanitarianAidData.morocco;
  return <DetailPage {...data} />;
}

import DetailPage from "./detail-page";
import { humanitarianAidData } from "@shared/fazaat-data";

export default function Sudan() {
  const data = humanitarianAidData.sudan;
  return <DetailPage {...data} />;
}

import DetailPage from "./detail-page";
import { humanitarianAidData } from "@shared/fazaat-data";

export default function Haiti() {
  const data = humanitarianAidData.haiti;
  return <DetailPage {...data} />;
}

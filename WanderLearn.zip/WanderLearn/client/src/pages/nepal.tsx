import DetailPage from "./detail-page";
import { humanitarianAidData } from "@shared/fazaat-data";

export default function Nepal() {
  const data = humanitarianAidData.nepal;
  return <DetailPage {...data} />;
}

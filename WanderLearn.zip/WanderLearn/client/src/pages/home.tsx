import Header from "@/components/Header";
import Hero from "@/components/Hero";
import Statistics from "@/components/Statistics";
import HistoricalSupport from "@/components/HistoricalSupport";
import HumanitarianAid from "@/components/HumanitarianAid";
import PeaceReconstruction from "@/components/PeaceReconstruction";
import ContemporaryGiving from "@/components/ContemporaryGiving";
import Team from "@/components/Team";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <div className="min-h-screen bg-background" dir="rtl">
      <Header />
      <Hero />
      <Statistics />
      <HistoricalSupport />
      <HumanitarianAid />
      <PeaceReconstruction />
      <ContemporaryGiving />
      <Team />
      <Footer />
    </div>
  );
}

import DetailPage from "./detail-page";
import { historicalFazaatData } from "@shared/fazaat-data";

export default function Lebanon() {
  const data = historicalFazaatData.lebanon;
  return <DetailPage {...data} />;
}

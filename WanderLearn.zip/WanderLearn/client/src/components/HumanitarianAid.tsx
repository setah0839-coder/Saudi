import { motion } from "framer-motion";
import { useEffect, useRef, useState } from "react";
import { Link } from "wouter";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function HumanitarianAid() {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current);
      }
    };
  }, []);

  const aidEvents = [
    {
      flag: "🇲🇦",
      title: "زلزال المغرب",
      description: "استجابة سريعة لزلزال المغرب 2023 بإرسال فرق الإنقاذ والمساعدات الطبية والغذائية للمناطق المتضررة.",
      year: "2023",
      type: "مساعدات عاجلة",
      image: "https://images.unsplash.com/photo-1591608971362-f08b2a75731a?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500",
      reverse: false,
      link: "/morocco",
    },
    {
      flag: "🇵🇰",
      title: "فيضانات باكستان",
      description: "جسر جوي للمساعدات الإنسانية لضحايا الفيضانات في باكستان، مع دعم لإعادة بناء البنية التحتية.",
      year: "2010, 2022",
      type: "إغاثة وإعمار",
      image: "https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500",
      reverse: true,
      link: "/pakistan",
    },
    {
      flag: "🇭🇹",
      title: "زلزال هاييتي",
      description: "مساعدات إنسانية واسعة لضحايا زلزال هاييتي 2010، شملت المأوى والغذاء والرعاية الطبية.",
      year: "2010",
      type: "إغاثة طارئة",
      image: "https://images.unsplash.com/photo-1536257104079-aa99c6460a5a?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500",
      reverse: false,
      link: "/haiti",
    },
    {
      flag: "🇳🇵",
      title: "زلزال نيبال",
      description: "دعم عاجل لضحايا زلزال نيبال 2015، مع مساعدات لإعادة بناء المعابد والمواقع التاريخية.",
      year: "2015",
      type: "إنقاذ وإعمار",
      image: "https://images.unsplash.com/photo-1544735716-392fe2489ffa?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500",
      reverse: true,
      link: "/nepal",
    },
    {
      flag: "🇹🇷🇸🇾",
      title: "زلزال تركيا وسوريا",
      description: "حملة إغاثية ضخمة لمساعدة ضحايا زلزال تركيا وسوريا 2023، بمشاركة فرق إنقاذ ومساعدات بمليارات الدولارات.",
      year: "2023",
      type: "عملية إنقاذ كبرى",
      image: "https://images.unsplash.com/photo-1547683905-f686c993aae5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500",
      reverse: false,
      link: "/turkeysyria",
    },
    {
      flag: "🇸🇩",
      title: "فيضانات السودان",
      description: "مساعدات عاجلة لمتضرري الفيضانات في السودان، شملت الغذاء والمأوى والرعاية الصحية.",
      year: "2020-2023",
      type: "دعم مستمر",
      image: "https://images.unsplash.com/photo-1532629345422-7515f3d16bb6?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500",
      reverse: true,
      link: "/sudan",
    },
  ];

  return (
    <section id="humanitarian" className="bg-white py-20" ref={sectionRef}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-black text-primary mb-4">المساعدات الإنسانية</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            استجابة سريعة وفعالة للكوارث الطبيعية حول العالم، إغاثة فورية وإعادة إعمار
          </p>
        </motion.div>

        <div className="space-y-12">
          {aidEvents.map((event, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: event.reverse ? 50 : -50 }}
              animate={isVisible ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className={`bg-gradient-to-${event.reverse ? "r" : "l"} from-primary/5 to-transparent rounded-xl p-8 hover:shadow-lg transition-shadow`}
              data-testid={`card-humanitarian-${index}`}
            >
              <div className="grid md:grid-cols-2 gap-8 items-center">
                <div className={event.reverse ? "order-1 md:order-2" : ""}>
                  <div className="flex items-center gap-3 mb-4">
                    <span className="text-4xl">{event.flag}</span>
                    <h3 className="text-3xl font-bold text-primary">{event.title}</h3>
                  </div>
                  <p className="text-foreground mb-4 text-lg leading-relaxed">{event.description}</p>
                  <div className="flex flex-wrap gap-2 mb-4">
                    <span className="bg-primary text-primary-foreground px-4 py-2 rounded-lg font-bold">{event.year}</span>
                    <span className="bg-accent/20 text-foreground px-4 py-2 rounded-lg font-semibold">{event.type}</span>
                  </div>
                  <Link href={event.link}>
                    <Button 
                      className="bg-primary hover:bg-primary/90 text-primary-foreground font-bold" 
                      data-testid={`button-humanitarian-${index}`}
                    >
                      اقرأ المزيد واستشعر العظمة
                      <ArrowLeft className="mr-2" size={18} />
                    </Button>
                  </Link>
                </div>
                <div className={`h-64 rounded-lg overflow-hidden shadow-lg ${event.reverse ? "order-2 md:order-1" : ""}`}>
                  <img src={event.image} alt={event.title} className="w-full h-full object-cover" />
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

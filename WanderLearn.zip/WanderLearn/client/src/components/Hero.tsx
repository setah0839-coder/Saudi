import { motion } from "framer-motion";

export default function Hero() {
  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  return (
    <section className="relative h-[600px] flex items-center justify-center text-center overflow-hidden">
      <div className="absolute inset-0 hero-gradient"></div>
      <div className="absolute inset-0 bg-black opacity-40"></div>
      <div
        className="absolute inset-0 bg-cover bg-center opacity-30"
        style={{
          backgroundImage:
            "url('https://images.unsplash.com/photo-1591608971362-f08b2a75731a?ixlib=rb-4.0.3&auto=format&fit=crop&w=2000&h=1200')",
        }}
      ></div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="relative z-10 max-w-4xl mx-auto px-4"
      >
        <h1 className="text-5xl md:text-6xl font-black text-white mb-6 leading-tight">
          المملكة العربية السعودية
          <span className="block text-accent mt-2">يد العون الممتدة للعالم</span>
        </h1>
        <p className="text-xl md:text-2xl text-white/90 mb-8 font-medium leading-relaxed">
          تاريخ حافل بالعطاء والإنسانية، من الفزعات التاريخية إلى المساعدات المعاصرة
        </p>
        <div className="flex flex-wrap gap-4 justify-center">
          <button
            onClick={() => scrollToSection("#historical")}
            className="bg-white text-primary px-8 py-4 rounded-lg font-bold text-lg hover:bg-accent hover:text-foreground transition-all shadow-lg"
            data-testid="button-explore"
          >
            استكشف تاريخ العطاء
          </button>
          <button
            onClick={() => scrollToSection("#team")}
            className="bg-primary/20 backdrop-blur-sm text-white border-2 border-white px-8 py-4 rounded-lg font-bold text-lg hover:bg-white hover:text-primary transition-all"
            data-testid="button-team"
          >
            تعرف على الفريق
          </button>
        </div>
      </motion.div>
    </section>
  );
}

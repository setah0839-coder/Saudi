export default function Footer() {
  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  return (
    <footer className="bg-primary text-primary-foreground py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          <div>
            <h4 className="text-xl font-bold mb-4">المملكة العربية السعودية</h4>
            <p className="opacity-90 leading-relaxed">تاريخ من العطاء والإنسانية، يد ممتدة للعالم في السراء والضراء</p>
          </div>
          <div>
            <h4 className="text-xl font-bold mb-4">روابط سريعة</h4>
            <ul className="space-y-2">
              <li>
                <button
                  onClick={() => scrollToSection("#historical")}
                  className="opacity-90 hover:opacity-100 hover:underline text-right"
                  data-testid="link-footer-historical"
                >
                  الفزعات التاريخية
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection("#humanitarian")}
                  className="opacity-90 hover:opacity-100 hover:underline text-right"
                  data-testid="link-footer-humanitarian"
                >
                  المساعدات الإنسانية
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection("#peace")}
                  className="opacity-90 hover:opacity-100 hover:underline text-right"
                  data-testid="link-footer-peace"
                >
                  السلام والإعمار
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection("#contemporary")}
                  className="opacity-90 hover:opacity-100 hover:underline text-right"
                  data-testid="link-footer-contemporary"
                >
                  العطاء المعاصر
                </button>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="text-xl font-bold mb-4">معلومات الاتصال</h4>
            <p className="opacity-90 mb-2">مشروع طلابي توثيقي</p>
            <p className="opacity-90 mb-2">تحت إشراف أكاديمي</p>
            <p className="opacity-90">2025 ©</p>
          </div>
        </div>
        <div className="border-t border-white/20 pt-8 text-center">
          <p className="opacity-90">جميع الحقوق محفوظة © 2025 - مشروع توثيقي للدور الإنساني السعودي</p>
        </div>
      </div>
    </footer>
  );
}

import { motion } from "framer-motion";
import { useEffect, useRef, useState } from "react";
import { Link } from "wouter";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function HistoricalSupport() {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current);
      }
    };
  }, []);

  const historicalEvents = [
    {
      flag: "🇵🇸",
      title: "فلسطين",
      description: "دعم مستمر منذ عقود للقضية الفلسطينية من خلال المساعدات الإنسانية والدعم السياسي والاقتصادي.",
      period: "1948 - حتى اليوم",
      image: "https://images.unsplash.com/photo-1552799446-159ba9523315?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
      link: "/palestine",
    },
    {
      flag: "🇰🇼",
      title: "الكويت",
      description: "قيادة التحالف العربي والدولي لتحرير الكويت عام 1991، مع تقديم دعم شامل لإعادة الإعمار.",
      period: "1990-1991",
      image: "https://images.unsplash.com/photo-1583422409516-2895a77efded?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
      link: "/kuwait",
    },
    {
      flag: "🇧🇦",
      title: "البوسنة والهرسك",
      description: "دعم إنساني وإغاثي كبير خلال حرب البوسنة في التسعينات، مع مساعدات لإعادة الإعمار.",
      period: "1992-1995",
      image: "https://pixabay.com/get/g5ad27f5adfc0aa350165ccc74cbcaee76e1d6df7993b2254ca76efdf1116911c1686d4b6052a3e1fa17e5a921f11cc7c1ae532a335174398f58a25c91fbf4e5f_1280.jpg",
      link: "/bosnia",
    },
    {
      flag: "🇱🇧",
      title: "لبنان",
      description: "دعم مستمر خلال الحرب الأهلية وبعدها، مع مساعدات لإعادة الإعمار والاستقرار السياسي والاقتصادي.",
      period: "1975-1990",
      image: "https://pixabay.com/get/g56c17a9a7a5728366c6d7240307dd404d82a5e42632b9d76023b8cfc4cc781778051dd1ef1a79ac7eeee7db3d57686d08911ea5d7e6bf40bec4da2acdf04f22b_1280.jpg",
      link: "/lebanon",
    },
    {
      flag: "🇾🇪",
      title: "اليمن",
      description: "قيادة التحالف العربي لدعم الشرعية في اليمن، مع تقديم مساعدات إنسانية وإغاثية واسعة النطاق.",
      period: "2015 - حتى اليوم",
      image: "https://pixabay.com/get/g4845950dfce1144908ee97b3aa5ccbc54833e4a3e8ec94432eee0417df01a2c453b606dceaca055914254bd3b5a6ecc2866f7941bd8ed40664e20a5ef86696e4_1280.jpg",
      link: "/yemen",
    },
    {
      flag: "🇮🇶",
      title: "العراق",
      description: "دعم شامل للعراق في مواجهة التحديات الأمنية والإنسانية، مع مساعدات لإعادة الإعمار والتنمية.",
      period: "2003 - حتى اليوم",
      image: "https://pixabay.com/get/ga49652011e02ecda6a2748f6ab76925f77bd42c80f917f37937c80ba9082db7e15214a3fb791f063f46d0acf3d557e14b04ebeb4e45543d2f32f9203cf0185cc_1280.jpg",
      link: "/iraq",
    },
  ];

  return (
    <section id="historical" className="bg-secondary py-20" ref={sectionRef}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-black text-primary mb-4">الفزعات التاريخية للمملكة</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            مواقف تاريخية خالدة تعكس التزام المملكة بنصرة القضايا العادلة والدفاع عن الشعوب المظلومة
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {historicalEvents.map((event, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={isVisible ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="bg-white rounded-xl shadow-lg overflow-hidden hover:transform hover:-translate-y-1 hover:shadow-2xl transition-all duration-300"
              data-testid={`card-historical-${index}`}
            >
              <div className="h-48 bg-primary/10 relative overflow-hidden">
                <img src={event.image} alt={event.title} className="w-full h-full object-cover" />
              </div>
              <div className="p-6">
                <h3 className="text-2xl font-bold text-primary mb-3">
                  {event.flag} {event.title}
                </h3>
                <p className="text-foreground mb-4 leading-relaxed">{event.description}</p>
                <div className="flex flex-wrap gap-2 mb-4">
                  <span className="bg-primary/10 text-primary px-3 py-1 rounded-full text-sm font-semibold">
                    {event.period}
                  </span>
                </div>
                <Link href={event.link}>
                  <Button 
                    className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-bold" 
                    data-testid={`button-details-${index}`}
                  >
                    اقرأ المزيد واستشعر العظمة
                    <ArrowLeft className="mr-2" size={18} />
                  </Button>
                </Link>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

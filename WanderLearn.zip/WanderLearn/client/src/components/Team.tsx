import { motion } from "framer-motion";
import { useEffect, useRef, useState } from "react";

export default function Team() {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current);
      }
    };
  }, []);

  const teamMembers = [
    {
      name: "صيته الشلوي",
      role: "باحثة رئيسية",
      description: "متخصصة في البحث التاريخي وجمع المعلومات",
      gradient: "from-primary/20 to-accent/20",
    },
    {
      name: "يارا الزهراني",
      role: "مصممة المحتوى",
      description: "مسؤولة عن تنسيق وتصميم العرض",
      gradient: "from-accent/20 to-primary/20",
    },
    {
      name: "رهف النفيعي",
      role: "محررة النصوص",
      description: "مختصة بكتابة وتحرير المحتوى",
      gradient: "from-primary/20 to-accent/20",
    },
    {
      name: "غلا الثبيتي",
      role: "منسقة المشروع",
      description: "مسؤولة عن التنسيق العام والمتابعة",
      gradient: "from-accent/20 to-primary/20",
    },
  ];

  return (
    <section id="team" className="bg-secondary py-20" ref={sectionRef}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-black text-primary mb-4">فريق الإعداد</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            الطالبات المشاركات في إعداد هذا المشروع التوثيقي
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {teamMembers.map((member, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={isVisible ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="bg-white rounded-xl shadow-lg overflow-hidden hover:transform hover:-translate-y-1 hover:shadow-2xl transition-all duration-300"
              data-testid={`card-team-${index}`}
            >
              <div className={`h-64 bg-gradient-to-br ${member.gradient} flex items-center justify-center`}>
                <div className="w-32 h-32 bg-white rounded-full flex items-center justify-center shadow-lg">
                  <span className="text-6xl">👩‍🎓</span>
                </div>
              </div>
              <div className="p-6 text-center">
                <h3 className="text-xl font-bold text-primary mb-2">{member.name}</h3>
                <p className="text-muted-foreground mb-3">{member.role}</p>
                <p className="text-sm text-foreground">{member.description}</p>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Project Info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="mt-16 bg-white rounded-xl shadow-lg p-8"
        >
          <div className="text-center max-w-3xl mx-auto">
            <h3 className="text-2xl font-bold text-primary mb-4">عن المشروع</h3>
            <p className="text-foreground leading-relaxed mb-6">
              هذا المشروع هو جهد توثيقي شامل لتاريخ العطاء والإنسانية السعودية، أُعد بإشراف أكاديمي كجزء من المناهج الدراسية
              لتوثيق الدور الإنساني الرائد للمملكة العربية السعودية عبر العقود.
            </p>
            <p className="text-muted-foreground mb-4">
              <strong>الثانوية الثالثة والثلاثون</strong> - طالبات الصف الثالث ثانوي
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <span className="bg-primary/10 text-primary px-4 py-2 rounded-lg font-semibold">مشروع توثيقي</span>
              <span className="bg-accent/20 text-foreground px-4 py-2 rounded-lg font-semibold">بحث أكاديمي</span>
              <span className="bg-primary/10 text-primary px-4 py-2 rounded-lg font-semibold">تاريخ إنساني</span>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

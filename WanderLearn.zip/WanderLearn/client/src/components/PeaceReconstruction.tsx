import { motion } from "framer-motion";
import { useEffect, useRef, useState } from "react";
import { Check, ArrowLeft } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function PeaceReconstruction() {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current);
      }
    };
  }, []);

  const initiatives = [
    {
      flag: "🇱🇧",
      country: "لبنان",
      title: "إعادة إعمار لبنان",
      description: "مشاريع واسعة لإعادة بناء البنية التحتية اللبنانية بعد الحرب والانفجار، مع دعم الاستقرار الاقتصادي.",
      image: "https://images.unsplash.com/photo-1552799446-159ba9523315?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500",
      items: ["إعادة بناء المنازل والمدارس", "دعم القطاع الصحي", "برامج تنموية مستدامة"],
      link: "/lebanon-peace",
    },
    {
      flag: "🇪🇬",
      country: "مصر",
      title: "الدعم التنموي لمصر",
      description: "استثمارات ضخمة في المشاريع التنموية والاقتصادية لدعم الاستقرار والنمو في مصر الشقيقة.",
      image: "https://images.unsplash.com/photo-1539768942893-daf53e448371?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500",
      items: ["مشاريع بنية تحتية", "استثمارات اقتصادية", "دعم مالي مباشر"],
      link: "/egypt-peace",
    },
    {
      flag: "🇸🇾",
      country: "اللاجئون السوريون",
      title: "دعم اللاجئين السوريين",
      description: "استضافة ودعم شامل للاجئين السوريين مع برامج تعليمية وصحية وفرص عمل.",
      image: "https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500",
      items: ["مخيمات نموذجية", "تعليم وصحة مجانية", "فرص عمل وتدريب"],
      link: "/syria-refugees",
    },
  ];

  return (
    <section id="peace" className="bg-secondary py-20" ref={sectionRef}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-black text-primary mb-4">مبادرات السلام والإعمار</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            جهود طويلة المدى لبناء السلام وإعادة الإعمار في المناطق المتضررة من النزاعات
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {initiatives.map((initiative, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={isVisible ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="bg-white rounded-xl shadow-lg overflow-hidden hover:transform hover:-translate-y-1 hover:shadow-2xl transition-all duration-300"
              data-testid={`card-peace-${index}`}
            >
              <div className="h-56 relative overflow-hidden">
                <img src={initiative.image} alt={initiative.title} className="w-full h-full object-cover" />
                <div className="absolute top-4 right-4 bg-primary text-primary-foreground px-4 py-2 rounded-lg font-bold text-sm">
                  {initiative.flag} {initiative.country}
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-2xl font-bold text-primary mb-3">{initiative.title}</h3>
                <p className="text-foreground mb-4 leading-relaxed">{initiative.description}</p>
                <ul className="space-y-2 text-sm mb-4">
                  {initiative.items.map((item, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <Check className="text-accent text-lg flex-shrink-0 mt-0.5" size={18} />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
                <Link href={initiative.link}>
                  <Button 
                    className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-bold" 
                    data-testid={`button-peace-${index}`}
                  >
                    اقرأ المزيد واستشعر العظمة
                    <ArrowLeft className="mr-2" size={18} />
                  </Button>
                </Link>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

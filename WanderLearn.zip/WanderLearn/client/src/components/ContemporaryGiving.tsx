import { motion } from "framer-motion";
import { useEffect, useRef, useState } from "react";
import { Check } from "lucide-react";

export default function ContemporaryGiving() {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current);
      }
    };
  }, []);

  return (
    <section id="contemporary" className="bg-white py-20" ref={sectionRef}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-black text-primary mb-4">العطاء المعاصر</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            استجابة فورية للتحديات العالمية المعاصرة مع مبادرات مبتكرة للإغاثة والتنمية
          </p>
        </motion.div>

        {/* COVID-19 Response */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="bg-gradient-to-br from-primary/10 to-accent/5 rounded-2xl p-8 md:p-12 mb-12"
        >
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <div className="inline-flex items-center gap-2 bg-primary text-primary-foreground px-4 py-2 rounded-lg mb-4">
                <span className="text-2xl">🦠</span>
                <span className="font-bold">جائحة كورونا</span>
              </div>
              <h3 className="text-3xl md:text-4xl font-black text-primary mb-4">الاستجابة لجائحة كوفيد-19</h3>
              <p className="text-lg text-foreground mb-6 leading-relaxed">
                مبادرة عالمية شاملة لمكافحة الجائحة، شملت إرسال المساعدات الطبية والأدوية واللقاحات لأكثر من 80 دولة حول العالم.
              </p>
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="bg-white rounded-lg p-4 shadow-md">
                  <div className="text-3xl font-black text-primary mb-1">80+</div>
                  <div className="text-sm text-muted-foreground">دولة مستفيدة</div>
                </div>
                <div className="bg-white rounded-lg p-4 shadow-md">
                  <div className="text-3xl font-black text-primary mb-1">$500M+</div>
                  <div className="text-sm text-muted-foreground">قيمة المساعدات</div>
                </div>
              </div>
            </div>
            <div className="rounded-xl overflow-hidden shadow-2xl">
              <img
                src="https://images.unsplash.com/photo-1584036561566-baf8f5f1b144?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"
                alt="COVID-19 Response"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </motion.div>

        {/* Fighting Famine */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="bg-gradient-to-bl from-accent/10 to-primary/5 rounded-2xl p-8 md:p-12 mb-12"
        >
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div className="rounded-xl overflow-hidden shadow-2xl order-2 md:order-1">
              <img
                src="https://images.unsplash.com/photo-1593113598332-cd288d649433?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"
                alt="Fighting Famine"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="order-1 md:order-2">
              <div className="inline-flex items-center gap-2 bg-accent text-foreground px-4 py-2 rounded-lg mb-4">
                <span className="text-2xl">🌾</span>
                <span className="font-bold">مكافحة المجاعة</span>
              </div>
              <h3 className="text-3xl md:text-4xl font-black text-primary mb-4">برامج مكافحة الجوع العالمية</h3>
              <p className="text-lg text-foreground mb-6 leading-relaxed">
                مبادرات مستدامة لمكافحة الجوع والمجاعة في أفريقيا وآسيا، مع توفير الغذاء والدعم الزراعي طويل المدى.
              </p>
              <ul className="space-y-3">
                <li className="flex items-start gap-3">
                  <Check className="text-accent flex-shrink-0 mt-0.5" size={24} />
                  <span className="text-foreground">توزيع ملايين الوجبات الغذائية</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="text-accent flex-shrink-0 mt-0.5" size={24} />
                  <span className="text-foreground">مشاريع زراعية مستدامة</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="text-accent flex-shrink-0 mt-0.5" size={24} />
                  <span className="text-foreground">برامج تمكين المزارعين</span>
                </li>
              </ul>
            </div>
          </div>
        </motion.div>

        {/* King Salman Relief Center */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="bg-primary text-primary-foreground rounded-2xl p-8 md:p-12"
        >
          <div className="text-center max-w-4xl mx-auto">
            <div className="inline-flex items-center justify-center w-20 h-20 bg-white/20 rounded-full mb-6">
              <span className="text-4xl">👑</span>
            </div>
            <h3 className="text-3xl md:text-4xl font-black mb-4">مركز الملك سلمان للإغاثة والأعمال الإنسانية</h3>
            <p className="text-xl mb-8 leading-relaxed opacity-95">
              مؤسسة عالمية رائدة في العمل الإنساني، نفذت أكثر من 1,900 مشروع في 85 دولة بقيمة تجاوزت 6 مليارات دولار
            </p>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6">
                <div className="text-4xl font-black mb-2">1,900+</div>
                <div className="text-sm opacity-90">مشروع إنساني</div>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6">
                <div className="text-4xl font-black mb-2">85</div>
                <div className="text-sm opacity-90">دولة حول العالم</div>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6">
                <div className="text-4xl font-black mb-2">$6B+</div>
                <div className="text-sm opacity-90">قيمة المشاريع</div>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6">
                <div className="text-4xl font-black mb-2">50M+</div>
                <div className="text-sm opacity-90">مستفيد مباشر</div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

# Saudi Arabia Humanitarian Aid Website

## Overview

This is a React-based web application showcasing Saudi Arabia's history of humanitarian aid, international support, and peace initiatives. The site presents historical "Fazaat" (humanitarian interventions), disaster relief efforts, peace-building initiatives, and contemporary giving programs in an engaging, Arabic-language interface with RTL (right-to-left) layout support.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Build Tools**
- React 18 with TypeScript for type-safe component development
- Vite as the build tool and development server for fast hot module replacement
- Wouter for lightweight client-side routing instead of React Router

**UI Component System**
- Shadcn/ui components built on Radix UI primitives for accessible, unstyled components
- Tailwind CSS for utility-first styling with custom theme configuration
- Framer Motion for animation and scroll-triggered effects
- Custom CSS variables for theming with green primary color (#006400 range) and yellow accent

**State Management**
- TanStack Query (React Query) for server state management and data fetching
- Local component state using React hooks for UI interactions
- No global state management library (Redux/Zustand) - application relies on prop drilling and React Query

**Layout & Styling**
- RTL (right-to-left) layout for Arabic language support
- Cairo font family from Google Fonts
- Responsive design with mobile-first approach
- Custom gradient backgrounds and hero sections

**Component Structure**
- Page components in `client/src/pages/` for each route (home, detail pages for countries/initiatives)
- Reusable UI components in `client/src/components/` (Header, Footer, Hero, Statistics, Team)
- Generic DetailPage component for displaying individual country/initiative information
- Intersection Observer API for scroll-triggered animations

### Backend Architecture

**Server Framework**
- Express.js as the HTTP server
- Custom middleware for request logging and JSON parsing
- Vite middleware integration for development with HMR support
- Server-side rendering preparation (SSR-ready structure)

**API Structure**
- RESTful API endpoints prefixed with `/api`
- Routes defined in `server/routes.ts` (currently minimal structure)
- Request/response logging middleware with truncation for readability

**Data Layer**
- Abstract storage interface (`IStorage`) for data operations
- In-memory storage implementation (`MemStorage`) for development
- User CRUD operations (getUser, getUserByUsername, createUser)
- Designed for future migration to database persistence

### Data Storage Solutions

**Database Configuration**
- Drizzle ORM configured for PostgreSQL (Neon serverless)
- Schema defined in `shared/schema.ts` with Drizzle Zod integration
- Users table with UUID primary keys, username, and password fields
- Migration files output to `./migrations` directory
- Database connection via `DATABASE_URL` environment variable

**Current State**
- Application uses in-memory storage for development
- Database schema prepared but not actively used in routes
- Shared schema types exported for type safety across client/server

**Static Content Data**
- Historical Fazaat, humanitarian aid, and peace initiatives data stored in shared module (`@shared/fazaat-data`)
- No database queries for content display - all content is statically typed and imported

### External Dependencies

**Third-Party UI Libraries**
- Radix UI - Complete component primitive collection (@radix-ui/react-*)
- Framer Motion - Animation library for scroll effects and transitions
- Embla Carousel - Carousel/slider functionality
- Lucide React - Icon library
- CMDK - Command palette component

**Database & ORM**
- Drizzle ORM - TypeScript ORM for PostgreSQL
- @neondatabase/serverless - Neon serverless PostgreSQL driver
- Drizzle Zod - Schema validation integration

**Form & Validation**
- React Hook Form - Form state management
- @hookform/resolvers - Validation resolver integration
- Zod - Schema validation library

**Utilities**
- date-fns - Date manipulation and formatting
- clsx & tailwind-merge - Conditional className utilities
- class-variance-authority - Component variant management
- nanoid - Unique ID generation

**Development Tools**
- TypeScript - Type safety across the stack
- ESBuild - Fast JavaScript bundler for production builds
- TSX - TypeScript execution for development server
- Replit-specific plugins for development environment integration

**Session Management**
- connect-pg-simple - PostgreSQL session store for Express (configured but not actively used)